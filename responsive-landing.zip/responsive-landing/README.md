# responsive landing

A Pen created on CodePen.io. Original URL: [https://codepen.io/Rohini-VS-the-vuer/pen/PoMgjmv](https://codepen.io/Rohini-VS-the-vuer/pen/PoMgjmv).

